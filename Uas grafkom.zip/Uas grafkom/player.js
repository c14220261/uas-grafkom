import * as THREE from "three";
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export class Player {
    constructor(camera, controller, scene, speed, obstacles) {
        this.camera = camera;
        this.controller = controller;
        this.scene = scene;
        this.speed = speed;
        this.state = "idle";
        this.rotationVector = new THREE.Vector3(0, 0, 0);
        this.animations = {};
        this.mesh = null;
        this.mixer = null;
        this.obstacles = obstacles;
        this.loader = new GLTFLoader();
        this.boundingBox = new THREE.Box3();
        this.camera.setup(new THREE.Vector3(0, 0, 0), this.rotationVector);
        this.pitchUp = false;
        this.pitchDown = false;
        this.zoomIn = false;
        this.zoomOut = false;
        this.loadModel();
        this.timeline = 0;  // Add this line
    }

    updateBoundingBox() {
        if (this.mesh) {
            this.boundingBox.setFromObject(this.mesh);
        }
    }

    loadModel() {
        this.loader.load('resources/plane.glb', (gltf) => {
            gltf.scene.scale.setScalar(0.3);
            gltf.scene.traverse(c => {
                if (c.isMesh) {
                    c.castShadow = true;
                    c.receiveShadow = true;
                }
            });
            this.mesh = gltf.scene;
            this.scene.add(this.mesh);
            this.rotationVector.set(0, 0, 0);
            this.mesh.position.y = 108;
            this.mesh.rotation.y += Math.PI / 2;
            this.updateBoundingBox();
            this.mixer = new THREE.AnimationMixer(this.mesh);

            const onLoad = (animName, anim) => {
                const clip = anim.animations[0];
                const action = this.mixer.clipAction(clip);

                this.animations[animName] = {
                    clip: clip,
                    action: action,
                };
            };

        });
    }

    performTimedMovementAndRoll(dt) {
        const totalDuration = 70; 
        if (this.timeline < totalDuration) {
            this.timeline += dt;
            let direction;
            let targetRoll = 0;
            let yawSpeed = 0;
            let pitchSpeed = 0;
    
            
            const easeInOutQuad = (t) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t);
    
            if (this.timeline <= 5) {
              
                direction = new THREE.Vector3(0, 0, 10);  
                targetRoll = Math.PI / 6;  
            } else if (this.timeline <= 9) {
            
                direction = new THREE.Vector3(0, 0, -10);  
                targetRoll = -Math.PI / 6;  
            } else if (this.timeline <= 16) {
          
                direction = new THREE.Vector3(-10, 0, 0); 
                targetRoll = 0;  
                this.mesh.rotation.y = 4.8;  
            } else if (this.timeline <= 16.8) {
                direction = new THREE.Vector3(0, 0, -10); 
                targetRoll = Math.PI / 6; 
            } else if (this.timeline <= 21) {
                direction = new THREE.Vector3(10, 0, 0);  
                targetRoll = 0;  
                this.mesh.rotation.y = Math.PI / 2; 
            } else if (this.timeline <= 23) {
               
                direction = new THREE.Vector3(10, 0, 0);
            } else if (this.timeline <= 25) {
               
                direction = new THREE.Vector3(-10, 0, 0);  
                targetRoll = 0; 
                this.mesh.rotation.y = 4.8;  
            } else if (this.timeline <= 30) {
        
                yawSpeed = 5;
            } else if (this.timeline <= 35) {
                
                yawSpeed = -5;
            } else if (this.timeline <= 41) {
            
                pitchSpeed = 50;
                this.pitchUp = true;
            } else if (this.timeline <= 46) {
               
                pitchSpeed = -50;
                this.pitchDown = true;
            } else if (this.timeline <= 51) {
              
                this.zoomIn = true;
            } else if (this.timeline <= 55) {
              
                this.zoomOut = true;
            } else {
              
                this.pitchUp = false;
                this.pitchDown = false;
                this.zoomIn = false;
                this.zoomOut = false;
            }
    
            const movementVector = new THREE.Vector3(direction ? direction.x : 0, 0, direction ? direction.z : 0);
            movementVector.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationVector.y);
            this.mesh.position.add(movementVector.multiplyScalar(dt * this.speed));
    
         
            const currentRoll = this.mesh.rotation.z;
            const rollFactor = easeInOutQuad(this.timeline % 1);
            this.mesh.rotation.z = THREE.MathUtils.lerp(currentRoll, targetRoll, rollFactor);
    
            // Yaw player
            this.mesh.rotation.y += yawSpeed * dt;
    
            // Pitch player
            this.mesh.position.y += pitchSpeed * dt;
    
            const minRoll = -Math.PI / 3;  
            const maxRoll = Math.PI / 3;   
            this.mesh.rotation.z = THREE.MathUtils.clamp(this.mesh.rotation.z, minRoll, maxRoll);
    
            // Update bounding box and camera
            this.updateBoundingBox();
            this.camera.setup(this.mesh.position, this.rotationVector, this.mesh.rotation.z, this.zoomIn, this.zoomOut);
        }
    }
    
    update(dt) {
        this.camera.setup(new THREE.Vector3(0, 0, 0), this.rotationVector);

        if (!Array.isArray(this.obstacles)) {
            console.error("Obstacles must be an array.");
            return;
        }
        if (!this.mesh || !this.animations) return;

        // collision
        const originalPosition = this.mesh.position.clone();

        const direction = new THREE.Vector3(0, 0, 0);

        if (this.controller.keys['forward']) {
            direction.x = 10;
            this.mesh.rotation.y = Math.PI / 2;
        }
        if (this.controller.keys['backward']) {
            direction.x = -10;
            this.mesh.rotation.y = -Math.PI / 2;
        }
        if (this.controller.keys['left']) {
            direction.z = -10;
        }
        if (this.controller.keys['right']) {
            direction.z = 10;
        }

        // Pitch, yaw, and roll 
        const pitchSpeed = 50;
        const yawSpeed = 5;
        const rollSpeed = 5;

        const minRoll = -Math.PI / 3; 
        const maxRoll = Math.PI / 3;  

        if (this.controller.keys['pitchUp']) {
            this.mesh.position.y += pitchSpeed * dt;

            this.pitchUp = true;
        } else {
            this.pitchUp = false;
        }
        if (this.controller.keys['pitchDown']) {
            this.mesh.position.y -= pitchSpeed * dt;
            this.pitchDown = true;
        } else {
            this.pitchDown = false;
        }
        if (this.controller.keys['yawLeft']) {
            this.mesh.rotation.y += yawSpeed * dt;
        }
        if (this.controller.keys['yawRight']) {
            this.mesh.rotation.y -= yawSpeed * dt;
        }
        if (this.controller.keys['rollLeft']) {
            this.mesh.rotation.z -= rollSpeed * dt;
        }
        if (this.controller.keys['rollRight']) {
            this.mesh.rotation.z += rollSpeed * dt;
        }
        if (this.controller.keys['zoomIn']) {
            this.zoomIn = true;
        } else {
            this.zoomIn = false;
        }
        if (this.controller.keys['zoomOut']) {
            this.zoomOut = true;
        } else {
            this.zoomOut = false;
        }
     
        this.mesh.rotation.z = THREE.MathUtils.clamp(this.mesh.rotation.z, minRoll, maxRoll);

    
        if (!this.controller.keys['left'] && !this.controller.keys['right']) {
            this.mesh.rotation.z *= 0.9;
        }

        if (direction.length() === 0) {
            if (this.animations['idle']) {
                if (this.state !== "idle") {
                    this.mixer.stopAllAction();
                    this.state = "idle";
                }
                this.mixer.clipAction(this.animations['idle'].clip).play();
            }
        } else {
            if (this.animations['run']) {
                if (this.state !== "run") {
                    this.mixer.stopAllAction();
                    this.state = "run";
                }
                this.mixer.clipAction(this.animations['run'].clip).play();
            }
        }

        if (this.controller.mouseDown) {
            const dtMouse = this.controller.deltaMousePos;
            dtMouse.x = dtMouse.x / Math.PI;
            dtMouse.y = dtMouse.y / Math.PI;

            this.rotationVector.y += dtMouse.x * dt * 100;
            this.rotationVector.z += dtMouse.y * dt * 100;
        }

        
        this.performTimedMovementAndRoll(dt);

       
        const rollAngle = this.mesh.rotation.z / 6;
        const forwardVector = new THREE.Vector3(1, 0, 0);
        const rightVector = new THREE.Vector3(0, 0, 1);
        forwardVector.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationVector.y);
        rightVector.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.rotationVector.y);

        // Move the player
        this.mesh.position.add(forwardVector.multiplyScalar(dt * this.speed * direction.x));
        this.mesh.position.add(rightVector.multiplyScalar(dt * this.speed * direction.z));
        this.updateBoundingBox();

        this.camera.setup(this.mesh.position, this.rotationVector, rollAngle, this.zoomIn, this.zoomOut);
        for (let obstacle of this.obstacles) {
            if (!obstacle.hitbox || !obstacle.hitbox.isBox3) {
                console.error("Invalid hitbox for obstacle:", obstacle);
                continue;
            }

            // Check collision
            if (this.boundingBox.intersectsBox(obstacle.hitbox)) {
               
                this.mesh.position.copy(originalPosition);
                this.updateBoundingBox();
                break;
            }
        }
        if (this.mixer) {
            this.mixer.update(dt);
        }
    }
}

export class PlayerController {
    constructor() {
        this.keys = {
            "forward": false,
            "backward": false,
            "left": false,
            "right": false,
            "pitchUp": false,
            "pitchDown": false,
            "yawLeft": false,
            "yawRight": false,
            "rollLeft": false,
            "rollRight": false,
            "zoomIn": false,
            "zoomOut": false,
        };
        this.mousePos = new THREE.Vector2();
        this.mouseDown = false;
        this.deltaMousePos = new THREE.Vector2();
        document.addEventListener('keydown', (e) => this.onKeyDown(e), false);
        document.addEventListener('keyup', (e) => this.onKeyUp(e), false);
        document.addEventListener('mousemove', (e) => this.onMouseMove(e), false);
        document.addEventListener('mousedown', (e) => this.onMouseDown(e), false);
        document.addEventListener('mouseup', (e) => this.onMouseUp(e), false);
    }

    onMouseDown(event) {
        this.mouseDown = true;
    }

    onMouseUp(event) {
        this.mouseDown = false;
    }

    onMouseMove(event) {
        const currentMousePos = new THREE.Vector2(
            (event.clientX / window.innerWidth) * 2 - 1,
            (event.clientY / window.innerHeight) * 2 - 1
        );
        this.deltaMousePos.addVectors(currentMousePos, this.mousePos.multiplyScalar(-1));
        this.mousePos.copy(currentMousePos);
    }

    onKeyDown(event) {
        switch (event.keyCode) {
            case "W".charCodeAt(0):
            case "w".charCodeAt(0):
                this.keys['forward'] = true;
                break;
            case "S".charCodeAt(0):
            case "s".charCodeAt(0):
                this.keys['backward'] = true;
                break;
            case "A".charCodeAt(0):
            case "a".charCodeAt(0):
                this.keys['left'] = true;
                this.keys['rollLeft'] = true;
                break;
            case "D".charCodeAt(0):
            case "d".charCodeAt(0):
                this.keys['right'] = true;
                this.keys['rollRight'] = true;
                break;
            case "8".charCodeAt(0):
                this.keys['pitchUp'] = true;
                break;
            case "2".charCodeAt(0):
                this.keys['pitchDown'] = true;
                break;
            case "4".charCodeAt(0):
                this.keys['yawLeft'] = true;
                break;
            case "6".charCodeAt(0):
                this.keys['yawRight'] = true;
                break;
            case "Q".charCodeAt(0):
            case "q".charCodeAt(0):
                this.keys['zoomIn'] = true;
                break;
            case "E".charCodeAt(0):
            case "e".charCodeAt(0):
                this.keys['zoomOut'] = true;
                break;
            case "j".charCodeAt(0):
                
                break;
            case "k".charCodeAt(0):
                
                break;
        }
    }
    
    onKeyUp(event) {
        switch (event.keyCode) {
            case "W".charCodeAt(0):
            case "w".charCodeAt(0):
                this.keys['forward'] = false;
                break;
            case "S".charCodeAt(0):
            case "s".charCodeAt(0):
                this.keys['backward'] = false;
                break;
            case "A".charCodeAt(0):
            case "a".charCodeAt(0):
                this.keys['left'] = false;
                this.keys['rollLeft'] = false;
                break;
            case "D".charCodeAt(0):
            case "d".charCodeAt(0):
                this.keys['right'] = false;
                this.keys['rollRight'] = false;
                break;
            case "8".charCodeAt(0):
                this.keys['pitchUp'] = false;
                break;
            case "2".charCodeAt(0):
                this.keys['pitchDown'] = false;
                break;
            case "4".charCodeAt(0):
                this.keys['yawLeft'] = false;
                break;
            case "6".charCodeAt(0):
                this.keys['yawRight'] = false;
                break;
            case "Q".charCodeAt(0):
            case "q".charCodeAt(0):
                this.keys['zoomIn'] = false;
                break;
            case "E".charCodeAt(0):
            case "e".charCodeAt(0):
                this.keys['zoomOut'] = false;
                break;
            case "j".charCodeAt(0):
                
                break;
            case "k".charCodeAt(0):
                
                break;
        }
    }
}

export class ThirdPersonCamera {
    constructor(camera, positionOffset, targetOffset) {
        this.camera = camera;
        this.positionOffset = positionOffset;
        this.targetOffset = targetOffset;
    }

    setup(target, angle, rollAngle, zoomIn, zoomOut) {
        
        let temp = new THREE.Vector3().copy(this.positionOffset);
        temp.applyAxisAngle(new THREE.Vector3(angle.x, 1, 0), angle.y);
        temp.applyAxisAngle(new THREE.Vector3(angle.y, 0, 1), angle.z);
        temp.addVectors(target, temp);
        this.camera.position.copy(temp);

       
        temp = new THREE.Vector3().copy(this.targetOffset).add(target);
        console.log(zoomIn)
     
        if (zoomIn) {
            this.camera.position.x -= 2;
            this.camera.position.y += 2;
            
        } else if (zoomOut) {
            this.camera.position.x += 2;
            this.camera.position.y -=1; 
        }

      
        this.camera.lookAt(temp);

       
        this.camera.rotation.z = rollAngle - 1.55;
    }
}
