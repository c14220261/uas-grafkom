import * as THREE from "three";
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { Player, PlayerController, ThirdPersonCamera } from "./player.js";

class Main {
    static init() {
        var canvasRef = document.getElementById("Canvas");

     
        canvasRef.style.width = '1000%';
        canvasRef.style.height = '1000%';
        canvasRef.width = window.innerWidth;
        canvasRef.height = window.innerHeight;

        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(
            75, window.innerWidth / window.innerHeight, 0.1, 1000
        );
        this.renderer = new THREE.WebGLRenderer(
            { antialias: true, canvas: canvasRef }
        );
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;

        const textureLoader = new THREE.TextureLoader();
        const backgroundTexture = textureLoader.load('resources/skyee.jpg');
        this.scene.background = backgroundTexture;

        // Directional Light
        var directionalLight = new THREE.DirectionalLight(0xFFFFFF, 5);
        this.scene.add(directionalLight);
        directionalLight.position.set(1700, 500, -600);
        directionalLight.castShadow = true;
        directionalLight.shadow.camera.top = 30;
        directionalLight.shadow.camera.bottom = -30;
        directionalLight.shadow.camera.right = 30;
        directionalLight.shadow.camera.left = -30;

        // Sphere light source
        var lightSphereGeometry = new THREE.SphereGeometry(5, 32, 32);
        var lightSphereMaterial = new THREE.MeshBasicMaterial({ color: 0xffff00 });
        var lightSphere = new THREE.Mesh(lightSphereGeometry, lightSphereMaterial);
        lightSphere.position.copy(directionalLight.position);
        this.scene.add(lightSphere);

       // Transparent Sphere 
       var transparentSphereGeometry = new THREE.SphereGeometry(100, 32, 32);
       var transparentSphereMaterial = new THREE.MeshPhongMaterial({
           color: 0xFF0000,
           transparent: true,
           opacity: 0.5,
           shininess: 100, 
           specular: 0xFFFFFF, 
           reflectivity: 100 
       });
       var transparentSphere = new THREE.Mesh(transparentSphereGeometry, transparentSphereMaterial);
       transparentSphere.position.set(200, 3, 0); 
       this.scene.add(transparentSphere);

     
        this.loader = new GLTFLoader();
       
        this.obstacles = [];

        // Load Manhattan model
        this.loader.load('resources/manhattan.glb', (gltf) => {
           
            gltf.scene.traverse((child) => {
                if (child.isMesh) {
                    child.castShadow = true;
                    child.receiveShadow = true;
                    child.scale.set(0.3, 0.242, 0.3);
                    // Create hitbox building
                    const buildingHitbox = new THREE.Box3().setFromObject(child);
                    this.obstacles.push({ mesh: child, hitbox: buildingHitbox });
                }
            });
          
            this.scene.add(gltf.scene);

            if (Array.isArray(this.obstacles)) {
                const thirdPersonCamera = new ThirdPersonCamera(
                    this.camera, new THREE.Vector3(-5, 2, 0), new THREE.Vector3(0, 0, 0)
                );
                this.player = new Player(
                    thirdPersonCamera,
                    new PlayerController(),
                    this.scene,
                    10,
                    this.obstacles
                );
            } else {
                console.error("Main.obstacles is not an array!");
            }
        }, undefined, (error) => {
            console.error('An error happened', error);
        });

        // Load Lamp model
        this.loader.load('resources/Lamp.glb', (gltf) => {
           
            gltf.scene.traverse((child) => {
                if (child.isMesh) {
                    child.castShadow = true;
                    child.receiveShadow = true;
                    child.scale.set(5, 5, 5);
                    child.position.set(-410, 80, 20);
                    
                    const buildingHitbox = new THREE.Box3().setFromObject(child);
                    this.obstacles.push({ mesh: child, hitbox: buildingHitbox });
                    const pointLight = new THREE.PointLight(0xffff00, 100000, 1000); 
                    pointLight.position.set(-410, 120, 20); 
                    this.scene.add(pointLight);
                }
            });

           
            this.scene.add(gltf.scene);
        }, undefined, (error) => {
            console.error('An error happened', error);
        });

        //load drone
        this.loader.load('resources/drone.glb', (gltf) => {
           
            gltf.scene.traverse((child) => {
                if (child.isMesh) {
                    child.castShadow = true;
                    child.receiveShadow = true;
                    child.scale.setScalar(0.5);
                    child.position.set(0, 0, 0);
                   
                    const buildingHitbox = new THREE.Box3().setFromObject(child);
                    this.obstacles.push({ mesh: child, hitbox: buildingHitbox });
                    const pointLight = new THREE.PointLight(0xFF2400, 100000, 1000); // Color, intensity, distance
                    pointLight.position.set(-410, 120, 20); // Adjust position relative to plane
                    this.scene.add(pointLight);
                }
            });

         
            this.drone = gltf.scene;

        
            this.scene.add(gltf.scene);
        }, undefined, (error) => {
            console.error('An error happened', error);
        });

      
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
            canvasRef.width = window.innerWidth;
            canvasRef.height = window.innerHeight;
        });
    }

    static render(dt) {
        var timer = Date.now() * 0.0005;
        this.camera.position.x = Math.cos(timer) * 10;
        this.camera.position.z = Math.sin(timer) * 10;

        if (this.player) {
            this.player.update(dt);
        }
        if (this.drone) {
            const orbitRadius = 20; 
            const orbitSpeed = 5; 
            const lampPosition = new THREE.Vector3(-410, 120, 20); 

            this.drone.position.x = lampPosition.x + Math.cos(timer * orbitSpeed) * orbitRadius;
            this.drone.position.z = lampPosition.z + Math.sin(timer * orbitSpeed) * orbitRadius;
            this.drone.position.y = lampPosition.y;
        }
        this.renderer.render(this.scene, this.camera);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    Main.init();
    var clock = new THREE.Clock();
    function animate() {
        Main.render(clock.getDelta());
        requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);
});
